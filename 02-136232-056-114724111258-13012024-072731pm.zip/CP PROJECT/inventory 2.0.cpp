#include <iostream>
#include <fstream>
#include <cstring>
#include <algorithm>
#include<cctype>
#include<ctime>
#include <cstdio>
using namespace std;
double gtotal;
// Structure for product
struct Stock{
string name;
float price;
int quantity;

};
// structure for customer
struct Customer {
string name;
string address;
string phoneNumber;
string nicNumber;
};
// Function declaration
void loginadmin(string adminid, string adminpassword);
void logincounter(string counterid, string counterpassword);
void counter();
void admin();
void orderInventory();
void updateSales(double gtotal);
void update();
void displaystock();
void addstock();
void invoice(double gtotal);
void search();
void deleteitem();
bool isAlphaOrSpace(char c);
bool isValidNIC(const string& nicNumber);
bool isValidPhoneNumber(const string& phoneNumber);
void getCustomerDetails(Customer& customer, const string& prompt);
void clientdata();
int main()
{
system("cls");
//Decision to make whether admin or counter
string adminid = "admin", adminpassword = "1234", counterid = "counter", counterpassword = "5678";
char decision;
bool dis = true;
do
{
cout << "Press 1 admin \nPress 2 counter person\n------------------------------------\nEnter your choice : ";
cin >> decision;
if (decision == '1')
{
loginadmin(adminid, adminpassword);
dis = true;
break;
}
else if (decision == '2')
{
logincounter(counterid, counterpassword);
dis = true;
break;
}
else
{
cout << "Invalid response!!! please enter again....\n";
dis = false;
}
} while (dis == false);
}
void loginadmin(string adminid, string adminpassword)
{
string id, password;
bool des = true;
system("cls");
cout << "-------ADMINISTRATION-------------------\n" << endl;
do
{
// verifying  if user is admin or not
cout << "ID: ";
cin >> id;
cout << "PASSWORD:";
cin.ignore();
cin >> password;
if (id == adminid && password == adminpassword)
{
des = true;
admin();
break;
}
else
{
cout << "Invalid ID or PASSWORD. PLEASE ENTER AGAIN....\n" << endl;
des = false;
}
} while (des == false);
}
void logincounter(string counterid, string counterpassword)
{
// verifying if the user is counterperson or not
string id, password;
bool des = true;
system("cls");
cout << "-------COUNTERPERSON-------------------\n" << endl;
do
{
cout << "ID: ";
cin >> id;
cout << "PASSWORD:";
cin >> password;
if (id == counterid && password == counterpassword)
{
des = true;
counter();
break;
}
else
{
cout << "Invalid ID or PASSWORD. PLEASE ENTER AGAIN..\n" << endl;
des = false;
}
} while (des == false);
}
// main page admin
void admin() {
string adminpassword;
system("cls");
int choice;

cout << "=============================================================================================\n";
cout << "\t\t\t\tDEPARTMENT STORE\n ";
cout << "====================================================================\n";
cout << "1. Display Items in Inventory\n";
cout << "2. Add Items \n";
cout << "3. Check specific Item \n";
cout << "4. Update Items\n";
cout << "5. Delete item\n";
cout << "6. Sales\n";
cout << "7. Ordering Inventory\n";
cout << "8. Display client data\n";
cout << "9. Exit\n";
cout << "==============================================================================\n";
cout << " ENTER YOUR CHOICE :";
cin >> choice;
switch (choice)
{
case 1:
system("cls");
displaystock();
break;
case 2:
system("cls");
addstock();
break;
case 3:
system("cls");
search();
break;
case 4:
system("cls");
update();
break;
case 5:
system("cls");
deleteitem();
break;
case 6:
system("cls");
updateSales(gtotal);
break;

case 7:
system("cls");
orderInventory();
break;

case 8:
clientdata();
break;
case 9:
main();
break;
default:
exit;
break;
}
}
// Ordering Inventory
void orderInventory() {
system("cls");
ofstream orderFile("orders.txt", ios::app);

if (orderFile.is_open()) {
ifstream inventoryFile("inventory.txt");

if (inventoryFile.is_open()) {
Stock item;
bool orderPlaced = false;
int quantity;
cout << "Items with quantity less than 10:\n";
while (inventoryFile.eof()) {
getline(inventoryFile>>std::ws,item.name);
inventoryFile>> item.price;
inventoryFile>> item.quantity;
if (item.quantity < 10) {
cout << "Name: " << item.name << "\tQuantity: " << item.quantity << endl;
cout << "Quantity to order :" << endl;
cin>>quantity;
orderFile << "\nItem to Order: " << item.name;
orderFile << "\nQuantity: " << quantity << endl; // Assuming ordering 50 items, modify as needed
orderPlaced = true;
}
}

if (!orderPlaced) {
cout << "No items require ordering at the moment.\n";
}

inventoryFile.close();
} else {
cout << "Error opening inventory file.\n";
}

orderFile.close();
} else {
cout << "Error opening orders file.\n";
}
}
// Calculating sales
void updateSales(double gtotal) {
ofstream salesFile("sales.txt", ios::app);
char a;
if (salesFile.is_open()) {
// Get the current date and time
time_t now = time(0);
tm* ltm = localtime(&now);

// Convert integers to strings without using streams
char currentDate[20];
sprintf(currentDate, "%d/%d/%d", 1 + ltm->tm_mon, ltm->tm_mday, 1900 + ltm->tm_year);

// Write the sales information to the file
salesFile << "Date: " << currentDate << endl;
salesFile << "Total Sales: " << gtotal << endl;
salesFile << "--------------------------------------" << endl;

cout << "Sales updated successfully for the day.\n";
salesFile.close();
} else {
cout << "Error opening sales file.\n";
}
cout<<"Press any key and then enter to exit (except spacebar)"<<endl;
cin>> a;
admin();
}
// Adding new stock  in the existing file
bool isAlphaOrSpace(char c) {
return isalpha(c) || isspace(c);
}

void addstock() {
Stock g;
int choice;
ofstream os;
os.open("inventory.txt", ios::app);

cout << "---------Enter Details-------" << endl;
while (true) {
cout << "Enter Item name (alphabets only):" << endl;
getline(cin>>std::ws, g.name);

bool isValid = true;
for (size_t i = 0; i < g.name.size(); ++i) {
if (!isAlphaOrSpace(g.name[i])) {
isValid = false;
break;
}
}

if (isValid) {
transform(g.name.begin(), g.name.end(), g.name.begin(), ::tolower);
break;
}
else {
cout << "Invalid input. Please enter alphabets only." << endl;
}
}
cout << "Enter Price:" << endl;
cin >> g.price;
cout << "Enter Quantity:" << endl;
cin >> g.quantity;
cout << endl;

os << "\n" <<g.name ;
os << "\n"<<g.price;
os << "\n"<<g.quantity;
os.close();

cout << "Product Added Successfully!" << endl;
cout << "Do you want to add another product?" << endl;
cout << "Press 1 for YES & 2 for NO" << endl;
cin >> choice;
if (choice == 1) {
addstock();
}
else {
cout << "Back to MAIN MENU" << endl;
admin();

}
}
//display stock available in file
void displaystock(){
Stock q;
ifstream is;
is.open("inventory.txt");
if(is.is_open()){
string line;
cout<<"---------------Item List-------------"<<endl;
while(!is.eof()){
getline(is>>std::ws,q.name);
is>>q.price;
is>>q.quantity;
cout<<"Name :"<<q.name<<endl;
cout<<"Price :"<<q.price<<endl;
cout<<"Quantity :"<<q.quantity<<endl;
cout<<"---------------------------------------"<<endl;
}
}
else{
cout<<"File cannot be opened"<<endl;
}
is.close();
cout<<"Press any key and then enter to exit (except spacebar)"<<endl;
char a;
cin>> a;
admin();

}
// search
void search(){
Stock p;
Stock s;
string line;
while (true) {
cout << "Enter Item name you want to search(alphabets only):" << endl;
getline(cin>>std::ws, s.name);

bool isValid = true;
for (size_t i = 0; i < s.name.size(); ++i) {
if (!isAlphaOrSpace(s.name[i])) {
isValid = false;
break;
}
}

if (isValid) {
transform(s.name.begin(), s.name.end(),s.name.begin(), ::tolower);
break;
}
else {
cout << "Invalid input. Please enter alphabets only." << endl;
}
}
ifstream searchh;
searchh.open("inventory.txt");
if(searchh.is_open())
{
while(!searchh.eof())
{
searchh>>p.name;
searchh>>p.price;
searchh>>p.quantity;
if(s.name==p.name)
{
cout<<"-------------------------------------------------"<<endl;
cout<<"Name :"<<p.name<<endl;
cout<<"Price :"<<p.price<<endl;
cout<<"Quantity :"<<p.quantity<<endl;
}
}
}
char choice;
cout<<" Press 'y' to search any more item press any key(except spacebar and y)to back main menu"<<endl;
cin>>choice;
if (choice == 'Y' || choice == 'y'){
search();
}
else
{
admin();
}
}
//Deleting item
void deleteitem() {
Stock p;
Stock s;
string line;

while (true) {
cout << "Enter Item name you want to search to delete (alphabets only):" << endl;
getline(cin >> ws, s.name);

bool isValid = true;
for (size_t i = 0; i < s.name.size(); ++i) {
if (!isAlphaOrSpace(s.name[i])) {
isValid = false;
break;
}
}

if (isValid) {
transform(s.name.begin(), s.name.end(), s.name.begin(), ::tolower);
break;
} else {
cout << "Invalid input. Please enter alphabets only." << endl;
}
}

ifstream search;
search.open("inventory.txt");

if (search.is_open()) {
bool itemFound = false;
ofstream temp("temp.txt", ios::out);

while (!search.eof()) {
getline(search >> ws, p.name);
search >> p.price;
search >> p.quantity;

if (s.name == p.name) {
itemFound = true;
cout << "Item Found:" << endl;
cout << "Name : " << p.name << endl;
cout << "Price : " << p.price << endl;
cout << "Quantity : " << p.quantity << endl;

int choice;
cout << "Are you sure you want to delete this Item?" << endl;
cout << "Press 1 for YES and 2 for No" << endl;
cin >> choice;

if (choice == 1) {
// Do not write the item to temp.txt, effectively deleting it
cout << "Item Deleted" << endl;
} else {
// Write the item to temp.txt, preserving it
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
cout << "Item Not Deleted" << endl;
}
} else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
}

search.close();
temp.close();

remove("inventory.txt");
rename("temp.txt", "inventory.txt");

if (!itemFound) {
cout << "Item not found." << endl;
}
} else {
cout << "Error opening inventory file." << endl;
}
char choiceee;
cout<<" Press 'y' to delete any more item press any key(except spacebar and y)to back main menu"<<endl;
cin>>choiceee;
if (choiceee == 'Y' || choiceee == 'y'){
deleteitem();
}
else{
admin();


}
}
//update item
void update() {
Stock p;
Stock s;
string line;

cout << "Enter Item Name That You Want To Search" << endl;
getline(cin >> ws, s.name);

ofstream temp("temp.txt", ios::out);
ifstream search("inventory.txt");

if (search.is_open()) {
bool itemFound = false;

while (search >> ws >> p.name) {
search >> p.price;
search >> p.quantity;

if (s.name == p.name) {
itemFound = true;
cout << "Name: " << p.name << endl;
cout << "Price: " << p.price << endl;
cout << "Quantity: " << p.quantity << endl;

int choice;
char choicee;
cout << "Are you sure you want to update this Item?" << endl;
cout << "Press y for Yes & n for No" << endl;
cin >> choicee;
if (choicee == 'y' || choicee == 'Y') {
do {
cout << "Press 1 for Name, 2 for Price, and 3 for Quantity" << endl;
cin >> choice;

if (choice == 1) {
Stock l;
cout << "Enter Item name (alphabets only):" << endl;
getline(cin >> ws, l.name);

bool isValid = true;
for (size_t i = 0; i < l.name.size(); ++i) {
if (!isalpha(l.name[i]) && !isspace(l.name[i])) {
isValid = false;
break;
}
}

if (isValid) {
transform(l.name.begin(), l.name.end(), l.name.begin(), ::tolower);

if (p.name != l.name) {
temp << "\n" << l.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
}
else {
cout << "Invalid input. Please enter alphabets only." << endl;
}
}
else if (choice == 2) {
Stock l;
cout << "Enter New Price:" << endl;
cin >> l.price;

if (p.name != s.name) {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
else {
temp << "\n" << p.name;
temp << "\n" << l.price;
temp << "\n" << p.quantity;
}
}
else if (choice == 3) {
Stock l;
cout << "Enter New Quantity:" << endl;
cin >> l.quantity;
p.quantity += l.quantity;

if (p.name != s.name) {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
}
else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}

cout << "Do you want to update another characteristic? (y/n): ";
cin >> choicee;
} while (choicee == 'y' || choicee == 'Y');
}
else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
}
else {
temp << "\n" << p.name;
temp << "\n" << p.price;
temp << "\n" << p.quantity;
}
}

search.close();
temp.close();

if (itemFound) {
remove("inventory.txt");
rename("temp.txt", "inventory.txt");
cout << "Item Updated" << endl;
}
else {
cout << "Item not found " << endl;
remove("temp.txt");
}

char choiceeee;
cout<<" Press 'y' to Update any more item press any key(except spacebar and y)to back main menu"<<endl;
cin>>choiceeee;
if (choiceeee == 'Y' || choiceeee == 'y'){
update();
}
else{
admin();


}
}
else {
cout << "Error opening inventory file." << endl;
}
}
// counter mainpage
void counter()
{
system("cls");
int countchoice;
double gtotal=0;
cout << "=============================================================================================\n";
cout << "\t\t\t\tDEPARTMENT STORE\n ";
cout << "====================================================================\n";
cout << "1. Invoice\n";
cout << "2. Exit\n";
cout << "==============================================================================\n";
cout << " ENTER YOUR CHOICE :";
cin >> countchoice;
switch (countchoice)
{
case 1:
invoice(gtotal);
break;
case 2:
main();
break;
default:
exit;
break;
}
}
//checking NIC number
bool isValidNIC(const string& nicNumber) {
// Validate NIC number based on the assumed format "12345-1234567-8"
if (nicNumber.length() != 15) {
return false;
}

for (size_t i = 0; i < nicNumber.length(); ++i) {
if (i == 5 || i == 13) {
if (nicNumber[i] != '-') {
return false;
}
} else if (!isdigit(nicNumber[i])) {
return false;
}
}

return true;
}
//phonenumber check
bool isValidPhoneNumber(const string& phoneNumber)
{
// Check if the phone number contains at least 10 digits
size_t digitCount = count_if(phoneNumber.begin(), phoneNumber.end(), ::isdigit);
return digitCount >= 10;
}
//Customer Details
void getCustomerDetails(Customer& customer, const string& prompt) {
do {
cout << prompt;
getline(cin >> ws, customer.name);

if (customer.name.empty()) {
cout << "Name cannot be empty. Please enter a valid name.\n";
}
} while (customer.name.empty());

cout << "Enter customer address: ";
getline(cin >> ws, customer.address);

do {
cout << "Enter customer phone number: ";
getline(cin >> ws, customer.phoneNumber);

if (!isValidPhoneNumber(customer.phoneNumber)) {
cout << "Invalid phone number. Please enter a valid numeric phone number with at least 11 digits.\n";
}
} while (!isValidPhoneNumber(customer.phoneNumber));

do {
cout << "Enter customer NIC number: ";
getline(cin >> ws, customer.nicNumber);

if (!isValidNIC(customer.nicNumber)) {
cout << "Invalid NIC number. Please enter a valid numeric NIC number with a specific format(xxxxx-xxxxxxx-x).\n";
}
} while (!isValidNIC(customer.nicNumber));
}
// making receipt and calculating total
void invoice(double gtotal) {
string line;
system("cls");
Stock r;
Stock looks;
char ch;
float total;
double totall = 0;
int choice;

do{
ifstream search;
search.open("inventory.txt");
ofstream temp("temp.txt", ios::out);  // Create a temporary file

if (search.is_open())
{
cout << "Enter the item u want to purchase:";
getline(cin >> std::ws, looks.name);
cout << "The quantity u want to purchase :";
cin >> looks.quantity;

while (!search.eof())
{
getline(search >> std::ws, r.name);
search >> r.price;
search >> r.quantity;
if (looks.name == r.name)
{
total = r.price * looks.quantity;
totall += total;
cout << "Product:" << r.name << endl;
cout << "price of 1 item:" << r.price << "\t";
cout << "item purchased:" << looks.quantity << "\t";
cout << "total:" << total << endl;

// Update the item quantity in the inventory
r.quantity -= looks.quantity;
}
// Write the current item to the temporary file
temp << "\n" << r.name;
temp << "\n" << r.price;
temp << "\n" << r.quantity;
}
}
else
{
cout<<"Item not found"<<endl;
}

search.close();
temp.close();
remove("inventory.txt");
rename("temp.txt", "inventory.txt");

cout << "******************************" << endl;
cout << "Do you want to add new product?\nPress 'y'to enter new product else generate invoice " << endl;
cin >> ch;
} while (ch == 'y' || ch == 'Y');
cout << "-------------------------------------------------------------------\n";
cout << "TOTAL= " << totall << endl;
gtotal += totall;
cout << "************************" << endl;
Customer customer;
cout << "Enter customer details for the invoice:" << endl;
getCustomerDetails(customer,"Enter customer name: ");
ofstream invoiceFile("customer.txt", ios::app);

if (invoiceFile.is_open()) {
// Write customer details to the file
invoiceFile << "Customer Name: " << customer.name << endl;
invoiceFile << "Customer Address: " << customer.address << endl;
invoiceFile << "Customer Phone Number: " << customer.phoneNumber << endl;
invoiceFile << "Customer NIC Number: " << customer.nicNumber << endl;
cout << "********" << endl;
cout << "Press 1 to Generate a new invoice for a new customer or Press 2 to return to the main menu" << endl;
int choice;
cin >> choice;

if (choice == 1) {
invoiceFile.close();  // Close the file before calling invoice recursively
invoice(gtotal);
} else {
cout << "Back to MAIN MENU" << endl;
counter();
}
} else {
cout << "Error opening invoice file.\n";
}

invoiceFile.close();  // Close the file
cout << "************************" << endl;
cout << "Press 1 to Generate new invoice for new customer or Press 2 to return to main menu" << endl;
cin >> choice;
if (choice == 1)
{
invoice(gtotal);
}
else
{
cout << "Back to MAIN MENU" << endl;
counter();
}
}
void clientdata() {
system("cls");
ifstream customerFile("customer.txt");

if (customerFile.is_open()) {
cout << "**** Customer Details ****" << endl;
string line;

while (getline(customerFile, line)) {
cout << line << endl;
}

cout << "*************" << endl;
customerFile.close();
} else {
cout << "Error opening customer file.\n";
}
cout<<"----------------------------------------------------------------------------"<<endl;
cout<<"Press any key and then enter to exit (except spacebar)"<<endl;
char c;
cin>> c;
admin();

}



